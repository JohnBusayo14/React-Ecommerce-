import React, { Component } from 'react';
import Signup from './../../components/Signup';
import './styles.scss';

const Registration = props => {
  return <Signup />;
};

export default Registration;
