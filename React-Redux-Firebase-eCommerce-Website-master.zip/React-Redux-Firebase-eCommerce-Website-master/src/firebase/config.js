// firebase config
export const firebaseConfig = {};