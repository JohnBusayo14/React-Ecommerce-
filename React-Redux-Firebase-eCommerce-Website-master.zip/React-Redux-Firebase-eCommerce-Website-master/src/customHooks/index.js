import useAuth from './useAuth';
import useAdminAuth from './useAdminAuth';

export {
  useAuth,
  useAdminAuth
};